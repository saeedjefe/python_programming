from setuptools import setup

setup(
    name='dirty_grammar',
    version='1.0',
    description='this module contains useful methods for English Grammar',
    author='Saeed',
    author_email='Saeedjefe@gmail.com',
    url='www.Modern_al-khwarazmi.com',
    py_modules=['function_test'],


    )
